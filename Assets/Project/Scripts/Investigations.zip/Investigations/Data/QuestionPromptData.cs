using System.Collections.Generic;
using UnityEngine;

namespace Fabula.PawOrder
{
    [CreateAssetMenu(
        fileName = "QuestionPromptData",
        menuName = "Fabula/Paw Order/Investigations/Prompts/Question Prompt")]
    public sealed class QuestionPromptData : InvestigationPromptData
    {
        [SerializeField] private string questionId;
        [SerializeField] private bool isStartingQuestion;
        [SerializeField] private string questionGroup;
        [SerializeField] private List<InvestigationPromptData> relatedPrompts = new();

        public string QuestionId => questionId;
        public bool IsStartingQuestion => isStartingQuestion;
        public string QuestionGroup => questionGroup;
        public IReadOnlyList<InvestigationPromptData> RelatedPrompts => relatedPrompts;
    }
}
