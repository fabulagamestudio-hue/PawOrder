﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using UnityEditor;
using UnityEngine;

namespace Fabula.PawOrder.Editor
{
    public static class PawOrderCaseBootstrapImporter
    {
        private static readonly string XlsxPath = @"D:/Projetos Unity/Fabula/Documents/Paw&Order/FalemeSobreX_OrdemFinalPerguntas.xlsx";

        private const string Root = "Assets/Project/Scriptables/Investigations/PawOrder";
        private const string CharactersDir = Root + "/Characters";
        private const string ItemsDir = Root + "/Items";
        private const string QuestionsDir = Root + "/Questions";
        private const string OutcomesDir = Root + "/Outcomes";
        private const string InteractionsDir = Root + "/Interactions";
        private const string CasesDir = Root + "/Cases";
        private static readonly string[] SourceSheetNames = { "Planilha1", "Mapa Perguntas Final" };

        private static readonly string[] CharacterOrder = { "Milo", "Nina", "Vera", "Otto", "Greta", "Boris" };

        private static readonly Regex ItemReferenceRegex = new(@"\[(I\d+)\]", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex SuperscriptUnlockRegex = new(@"\(([⁰¹²³⁴⁵⁶⁷⁸⁹]+)\)", RegexOptions.Compiled);
        private static readonly Regex QuestionIdRegex = new(@"Q\d+", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        [MenuItem("Fabula/Paw Order/Investigations/Import Paw & Order Case Assets")]
        public static void ImportFromMenu() => ImportFromSpreadsheet();

        public static void ImportFromSpreadsheet()
        {
            if (!File.Exists(XlsxPath))
            {
                Debug.LogError($"PawOrder import failed: XLSX not found at '{XlsxPath}'.");
                return;
            }

            EnsureDirectoryStructure();
            var workbook = ParseWorkbook(XlsxPath, SourceSheetNames);

            var characters = EnsureCharacters();
            var items = EnsureItems(workbook.Items);
            var questions = EnsureQuestions(workbook.Questions);

            var unlockedQuestionIds = CollectUnlockedQuestionIdsFromResponses(workbook.Questions);
            ApplyStartingQuestions(questions, unlockedQuestionIds);

            var outcomeCount = 0;
            var interactionCount = 0;
            var allPrompts = new List<InvestigationPromptData>();
            allPrompts.AddRange(questions.Values.OrderBy(q => q.QuestionId, StringComparer.OrdinalIgnoreCase));
            allPrompts.AddRange(items.Values.OrderBy(i => i.PromptId, StringComparer.OrdinalIgnoreCase));

            foreach (var questionRow in workbook.Questions)
            {
                if (!questions.TryGetValue(questionRow.QuestionId, out var questionAsset))
                {
                    continue;
                }

                for (var index = 0; index < CharacterOrder.Length; index++)
                {
                    var characterName = CharacterOrder[index];
                    var response = questionRow.Responses[index]?.Trim();
                    if (string.IsNullOrWhiteSpace(response))
                    {
                        continue;
                    }

                    var outcome = CreateOrUpdateOutcome(questionRow.QuestionId, characterName, response, items, questions);
                    outcomeCount++;
                    CreateOrUpdateInteraction(questionRow.QuestionId, characterName, characters[characterName], questionAsset, outcome);
                    interactionCount++;
                }
            }

            CreateOrUpdateCase(characters, allPrompts, questions.Values.ToList());

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Debug.Log($"PawOrder import done. Items: {items.Count}, Questions: {questions.Count}, Outcomes: {outcomeCount}, Interactions: {interactionCount}.");
        }

        private static Dictionary<string, CharacterData> EnsureCharacters()
        {
            var result = new Dictionary<string, CharacterData>(StringComparer.OrdinalIgnoreCase);

            foreach (var name in CharacterOrder)
            {
                var existing = FindCharacterByNameOrId(name);
                if (existing != null)
                {
                    result[name] = existing;
                    continue;
                }

                var path = $"{CharactersDir}/{name}.asset";
                var created = ScriptableObject.CreateInstance<CharacterData>();
                AssetDatabase.CreateAsset(created, path);

                var so = new SerializedObject(created);
                so.FindProperty("characterId").stringValue = name;
                so.FindProperty("displayName").stringValue = name;
                so.FindProperty("isSuspect").boolValue = false;
                so.FindProperty("canBeChosenAsCulprit").boolValue = false;
                so.ApplyModifiedPropertiesWithoutUndo();

                result[name] = created;
            }

            return result;
        }

        private static CharacterData FindCharacterByNameOrId(string characterName)
        {
            var guids = AssetDatabase.FindAssets("t:CharacterData");
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var asset = AssetDatabase.LoadAssetAtPath<CharacterData>(path);
                if (asset == null)
                {
                    continue;
                }

                var so = new SerializedObject(asset);
                var id = so.FindProperty("characterId")?.stringValue;
                var display = so.FindProperty("displayName")?.stringValue;
                if (string.Equals(id, characterName, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(display, characterName, StringComparison.OrdinalIgnoreCase))
                {
                    return asset;
                }
            }

            return null;
        }

        private static Dictionary<string, ItemPromptData> EnsureItems(List<ItemRow> itemRows)
        {
            var result = new Dictionary<string, ItemPromptData>(StringComparer.OrdinalIgnoreCase);

            foreach (var row in itemRows)
            {
                var fileName = $"{row.ItemCode}_{ToSafeSlug(row.ItemName)}.asset";
                var path = $"{ItemsDir}/{fileName}";
                var item = AssetDatabase.LoadAssetAtPath<ItemPromptData>(path);
                if (item == null)
                {
                    item = ScriptableObject.CreateInstance<ItemPromptData>();
                    AssetDatabase.CreateAsset(item, path);
                }

                var so = new SerializedObject(item);
                so.FindProperty("promptId").stringValue = row.ItemCode;
                so.FindProperty("displayName").stringValue = row.ItemName;
                so.FindProperty("promptType").enumValueIndex = (int)InvestigationPromptType.Item;
                so.ApplyModifiedPropertiesWithoutUndo();

                result[row.ItemCode] = item;
            }

            return result;
        }

        private static Dictionary<string, QuestionPromptData> EnsureQuestions(List<QuestionRow> questionRows)
        {
            var result = new Dictionary<string, QuestionPromptData>(StringComparer.OrdinalIgnoreCase);

            foreach (var row in questionRows)
            {
                var fileName = $"{row.QuestionId}_{ToSafeSlug(row.QuestionText)}.asset";
                var path = $"{QuestionsDir}/{fileName}";
                var question = AssetDatabase.LoadAssetAtPath<QuestionPromptData>(path);
                if (question == null)
                {
                    question = ScriptableObject.CreateInstance<QuestionPromptData>();
                    AssetDatabase.CreateAsset(question, path);
                }

                var so = new SerializedObject(question);
                so.FindProperty("questionId").stringValue = row.QuestionId;
                so.FindProperty("promptId").stringValue = row.QuestionId;
                so.FindProperty("displayName").stringValue = row.QuestionText;
                so.FindProperty("promptType").enumValueIndex = (int)InvestigationPromptType.Question;
                so.ApplyModifiedPropertiesWithoutUndo();

                result[row.QuestionId] = question;
            }

            return result;
        }

        private static HashSet<string> CollectUnlockedQuestionIdsFromResponses(List<QuestionRow> rows)
        {
            var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var row in rows)
            {
                foreach (var response in row.Responses)
                {
                    if (string.IsNullOrWhiteSpace(response))
                    {
                        continue;
                    }

                    foreach (Match match in SuperscriptUnlockRegex.Matches(response))
                    {
                        var digits = SuperscriptToDigits(match.Groups[1].Value);
                        if (!string.IsNullOrWhiteSpace(digits))
                        {
                            result.Add("Q" + digits.PadLeft(2, '0'));
                        }
                    }
                }
            }

            return result;
        }

        private static void ApplyStartingQuestions(Dictionary<string, QuestionPromptData> questions, HashSet<string> unlockedQuestionIds)
        {
            var foundAny = false;
            foreach (var pair in questions)
            {
                var isStarting = !unlockedQuestionIds.Contains(pair.Key);
                var so = new SerializedObject(pair.Value);
                so.FindProperty("isStartingQuestion").boolValue = isStarting;
                so.ApplyModifiedPropertiesWithoutUndo();
                foundAny |= isStarting;
            }

            if (!foundAny && questions.TryGetValue("Q01", out var q01))
            {
                var so = new SerializedObject(q01);
                so.FindProperty("isStartingQuestion").boolValue = true;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
        }

        private static InteractionOutcomeData CreateOrUpdateOutcome(
            string questionId,
            string characterName,
            string response,
            IReadOnlyDictionary<string, ItemPromptData> items,
            IReadOnlyDictionary<string, QuestionPromptData> questions)
        {
            var dir = $"{OutcomesDir}/{questionId}";
            EnsureDirectory(dir);

            var outcomeId = $"Outcome_{questionId}_{characterName}";
            var path = $"{dir}/{outcomeId}.asset";

            var outcome = AssetDatabase.LoadAssetAtPath<InteractionOutcomeData>(path);
            if (outcome == null)
            {
                outcome = ScriptableObject.CreateInstance<InteractionOutcomeData>();
                AssetDatabase.CreateAsset(outcome, path);
            }

            var so = new SerializedObject(outcome);
            so.FindProperty("outcomeId").stringValue = outcomeId;
            so.FindProperty("responseText").stringValue = response;
            so.FindProperty("proofSummary").stringValue = string.Empty;
            so.FindProperty("createsUsableProof").boolValue = false;
            so.FindProperty("marksPromptAsImportant").boolValue = false;

            var referencedPrompts = ResolveReferencedItems(response, items);
            SetObjectList(so.FindProperty("referencedPrompts"), referencedPrompts);

            var unlockPrompts = ResolveUnlockQuestions(response, questions);
            SetObjectList(so.FindProperty("unlocksPrompts"), unlockPrompts);

            so.FindProperty("suspectEvidenceValues").arraySize = 0;
            so.ApplyModifiedPropertiesWithoutUndo();

            return outcome;
        }

        private static void CreateOrUpdateInteraction(
            string questionId,
            string characterName,
            CharacterData character,
            QuestionPromptData question,
            InteractionOutcomeData outcome)
        {
            var dir = $"{InteractionsDir}/{characterName}";
            EnsureDirectory(dir);

            var interactionId = $"Interaction_{questionId}_{characterName}";
            var path = $"{dir}/{interactionId}.asset";

            var interaction = AssetDatabase.LoadAssetAtPath<CharacterInteractionData>(path);
            if (interaction == null)
            {
                interaction = ScriptableObject.CreateInstance<CharacterInteractionData>();
                AssetDatabase.CreateAsset(interaction, path);
            }

            var so = new SerializedObject(interaction);
            so.FindProperty("interactionId").stringValue = interactionId;
            so.FindProperty("targetCharacter").objectReferenceValue = character;
            so.FindProperty("promptUsed").objectReferenceValue = question;
            so.FindProperty("outcome").objectReferenceValue = outcome;
            so.FindProperty("canRepeat").boolValue = true;
            so.FindProperty("consumeInteraction").boolValue = false;

            var requirements = so.FindProperty("requirements");
            requirements.FindPropertyRelative("requiredKnownPrompts").arraySize = 0;
            requirements.FindPropertyRelative("requiredKnownOutcomes").arraySize = 0;
            requirements.FindPropertyRelative("requiredCollectedItems").arraySize = 0;
            requirements.FindPropertyRelative("requiredUnlockedLocations").arraySize = 0;

            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static void CreateOrUpdateCase(
            Dictionary<string, CharacterData> characters,
            List<InvestigationPromptData> allPrompts,
            List<QuestionPromptData> allQuestions)
        {
            var path = $"{CasesDir}/PawOrder_MainCase.asset";
            var caseData = AssetDatabase.LoadAssetAtPath<CaseData>(path);
            if (caseData == null)
            {
                caseData = ScriptableObject.CreateInstance<CaseData>();
                AssetDatabase.CreateAsset(caseData, path);
            }

            var so = new SerializedObject(caseData);
            so.FindProperty("caseId").stringValue = "PawOrder_MainCase";
            so.FindProperty("caseTitle").stringValue = "Paw & Order";

            SetObjectList(so.FindProperty("allCharacters"), characters.Values.OrderBy(c => c.name).ToList());
            SetObjectList(so.FindProperty("allPrompts"), allPrompts);

            var startingPrompts = new List<InvestigationPromptData>();
            foreach (var question in allQuestions)
            {
                var qso = new SerializedObject(question);
                if (qso.FindProperty("isStartingQuestion").boolValue)
                {
                    startingPrompts.Add(question);
                }
            }

            SetObjectList(so.FindProperty("startingPrompts"), startingPrompts);

            var suspects = new List<CharacterData>();
            foreach (var character in characters.Values)
            {
                var cso = new SerializedObject(character);
                if (cso.FindProperty("isSuspect").boolValue)
                {
                    suspects.Add(character);
                }
            }

            SetObjectList(so.FindProperty("suspects"), suspects);
            so.FindProperty("allLocations").arraySize = 0;
            so.FindProperty("startingUnlockedLocations").arraySize = 0;
            so.FindProperty("startingLocation").objectReferenceValue = null;

            so.ApplyModifiedPropertiesWithoutUndo();
        }

        private static List<InvestigationPromptData> ResolveReferencedItems(string response, IReadOnlyDictionary<string, ItemPromptData> items)
        {
            var result = new List<InvestigationPromptData>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (Match match in ItemReferenceRegex.Matches(response))
            {
                var code = match.Groups[1].Value.ToUpperInvariant();
                if (!seen.Add(code))
                {
                    continue;
                }

                if (items.TryGetValue(code, out var item))
                {
                    result.Add(item);
                }
            }

            return result;
        }

        private static List<InvestigationPromptData> ResolveUnlockQuestions(string response, IReadOnlyDictionary<string, QuestionPromptData> questions)
        {
            var result = new List<InvestigationPromptData>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (Match match in SuperscriptUnlockRegex.Matches(response))
            {
                var digits = SuperscriptToDigits(match.Groups[1].Value);
                if (string.IsNullOrWhiteSpace(digits))
                {
                    continue;
                }

                var key = "Q" + digits.PadLeft(2, '0');
                if (!seen.Add(key))
                {
                    continue;
                }

                if (questions.TryGetValue(key, out var question))
                {
                    result.Add(question);
                }
            }

            return result;
        }

        private static void SetObjectList<T>(SerializedProperty property, IList<T> values) where T : UnityEngine.Object
        {
            property.arraySize = values.Count;
            for (var i = 0; i < values.Count; i++)
            {
                property.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
            }
        }

        private static string ToSafeSlug(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "Empty";
            }

            var normalized = value.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();

            foreach (var ch in normalized)
            {
                var category = CharUnicodeInfo.GetUnicodeCategory(ch);
                if (category == UnicodeCategory.NonSpacingMark)
                {
                    continue;
                }

                if (char.IsLetterOrDigit(ch))
                {
                    sb.Append(ch);
                }
                else
                {
                    sb.Append('_');
                }
            }

            var cleaned = Regex.Replace(sb.ToString(), "_+", "_").Trim('_');
            return string.IsNullOrWhiteSpace(cleaned) ? "Entry" : cleaned;
        }

        private static string SuperscriptToDigits(string superscript)
        {
            if (string.IsNullOrWhiteSpace(superscript))
            {
                return string.Empty;
            }

            var sb = new StringBuilder(superscript.Length);
            foreach (var ch in superscript)
            {
                sb.Append(ch switch
                {
                    '⁰' => '0',
                    '¹' => '1',
                    '²' => '2',
                    '³' => '3',
                    '⁴' => '4',
                    '⁵' => '5',
                    '⁶' => '6',
                    '⁷' => '7',
                    '⁸' => '8',
                    '⁹' => '9',
                    _ => '\0'
                });
            }

            return new string(sb.ToString().Where(char.IsDigit).ToArray());
        }

        private static void EnsureDirectoryStructure()
        {
            EnsureDirectory(Root);
            EnsureDirectory(CharactersDir);
            EnsureDirectory(ItemsDir);
            EnsureDirectory(QuestionsDir);
            EnsureDirectory(OutcomesDir);
            EnsureDirectory(InteractionsDir);
            EnsureDirectory(CasesDir);
        }

        private static void EnsureDirectory(string assetPath)
        {
            var parts = assetPath.Split('/');
            var current = parts[0];
            for (var i = 1; i < parts.Length; i++)
            {
                var next = $"{current}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                current = next;
            }
        }

        private static ParsedWorkbook ParseWorkbook(string xlsxPath, IReadOnlyList<string> sheetNames)
        {
            using var fileStream = new FileStream(xlsxPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var archive = new ZipArchive(fileStream, ZipArchiveMode.Read, leaveOpen: false);
            XNamespace mainNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            XNamespace relNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            XNamespace pkgRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";

            var sharedStrings = ReadSharedStrings(archive, mainNs);
            var workbookDoc = XDocument.Load(archive.GetEntry("xl/workbook.xml")!.Open());
            var workbookRelsDoc = XDocument.Load(archive.GetEntry("xl/_rels/workbook.xml.rels")!.Open());

            var relationships = workbookRelsDoc.Root!
                .Elements(pkgRelNs + "Relationship")
                .ToDictionary(e => (string)e.Attribute("Id")!, e => (string)e.Attribute("Target")!);

            var sheets = workbookDoc.Root!
                .Element(mainNs + "sheets")!
                .Elements(mainNs + "sheet")
                .ToList();

            var items = new List<ItemRow>();
            var questions = new List<QuestionRow>();

            foreach (var sheetName in sheetNames)
            {
                var questionRowsInSheet = 0;
                var itemRowsInSheet = 0;
                var sheet = sheets.FirstOrDefault(e => string.Equals((string)e.Attribute("name"), sheetName, StringComparison.OrdinalIgnoreCase));
                if (sheet == null)
                {
                    Debug.LogWarning($"PawOrder import: sheet '{sheetName}' not found in workbook, skipping.");
                    continue;
                }

                var relationId = (string)sheet.Attribute(relNs + "id")!;
                var target = relationships[relationId].Replace("\\", "/");
                var worksheetDoc = XDocument.Load(archive.GetEntry("xl/" + target)!.Open());

                foreach (var row in worksheetDoc.Root!.Element(mainNs + "sheetData")!.Elements(mainNs + "row"))
                {
                    string CellText(string columnName)
                    {
                        var cell = row.Elements(mainNs + "c")
                            .FirstOrDefault(c => ((string)c.Attribute("r") ?? string.Empty).StartsWith(columnName, StringComparison.OrdinalIgnoreCase));

                        if (cell == null)
                        {
                            return string.Empty;
                        }

                        var cellType = (string)cell.Attribute("t");
                        if (cellType == "inlineStr")
                        {
                            return string.Concat(cell.Descendants(mainNs + "t").Select(t => t.Value));
                        }

                        var valueNode = cell.Element(mainNs + "v");
                        if (valueNode == null)
                        {
                            return string.Empty;
                        }

                        var raw = valueNode.Value;
                        if (cellType == "s" && int.TryParse(raw, out var index) && index >= 0 && index < sharedStrings.Count)
                        {
                            return sharedStrings[index];
                        }

                        return raw;
                    }

                    var rawQuestionId = CellText("A").Trim();
                    var questionText = CellText("B").Trim();

                    var questionMatch = QuestionIdRegex.Match(rawQuestionId);
                    if (questionMatch.Success && !string.IsNullOrWhiteSpace(questionText))
                    {
                        questionRowsInSheet++;
                        questions.Add(new QuestionRow
                        {
                            QuestionId = questionMatch.Value.ToUpperInvariant(),
                            QuestionText = questionText,
                            Responses = new[]
                            {
                                CellText("C").Trim(), CellText("D").Trim(), CellText("E").Trim(),
                                CellText("F").Trim(), CellText("G").Trim(), CellText("H").Trim()
                            }
                        });
                    }

                    var itemCode = CellText("J").Trim().ToUpperInvariant();
                    var itemName = CellText("K").Trim();
                    if (Regex.IsMatch(itemCode, "^I\\d+$") && !string.IsNullOrWhiteSpace(itemName))
                    {
                        itemRowsInSheet++;
                        items.Add(new ItemRow { ItemCode = itemCode, ItemName = itemName });
                    }
                }

                // Keep per-sheet counters to make import behavior visible in Unity Console.
                // This helps distinguish "updated existing assets" from "created new assets".
                // especially when multiple sheets share the same Qxx/Ixx identifiers.
                var stats = new SheetParseStats
                {
                    SheetName = sheetName,
                    QuestionRows = questionRowsInSheet,
                    ItemRows = itemRowsInSheet
                };
                Debug.Log($"PawOrder import: sheet '{stats.SheetName}' -> question rows: {stats.QuestionRows}, item rows: {stats.ItemRows}.");
            }

            return new ParsedWorkbook
            {
                Items = items
                    .GroupBy(i => i.ItemCode, StringComparer.OrdinalIgnoreCase)
                    .Select(g => g.First())
                    .OrderBy(i => i.ItemCode, StringComparer.OrdinalIgnoreCase)
                    .ToList(),
                Questions = questions
                    .GroupBy(q => q.QuestionId, StringComparer.OrdinalIgnoreCase)
                    .Select(g => g.First())
                    .OrderBy(q => q.QuestionId, StringComparer.OrdinalIgnoreCase)
                    .ToList()
            };
        }

        private static List<string> ReadSharedStrings(ZipArchive archive, XNamespace mainNs)
        {
            var entry = archive.GetEntry("xl/sharedStrings.xml");
            if (entry == null)
            {
                return new List<string>();
            }

            var doc = XDocument.Load(entry.Open());
            return doc.Root!
                .Elements(mainNs + "si")
                .Select(si => string.Concat(si.Descendants(mainNs + "t").Select(t => t.Value)))
                .ToList();
        }

        private sealed class ParsedWorkbook
        {
            public List<ItemRow> Items = new();
            public List<QuestionRow> Questions = new();
            public List<SheetParseStats> SheetStats = new();
        }

        private sealed class ItemRow
        {
            public string ItemCode = string.Empty;
            public string ItemName = string.Empty;
        }

        private sealed class QuestionRow
        {
            public string QuestionId = string.Empty;
            public string QuestionText = string.Empty;
            public string[] Responses = Array.Empty<string>();
        }

        private sealed class SheetParseStats
        {
            public string SheetName = string.Empty;
            public int QuestionRows;
            public int ItemRows;
        }
    }
}
