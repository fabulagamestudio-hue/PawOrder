using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Fabula.PawOrder;
using UnityEditor;
using UnityEngine;

namespace Fabula.PawOrder.Editor
{
    public static class PawOrderOutcomeEvidenceTool
    {
        private static readonly string[] Suspects = { "Greta", "Vera", "Milo", "Nina", "Otto", "Boris" };
        private const string OutcomesRoot = "Assets/Project/Scriptables/Investigations/PawOrder/Outcomes";

        [MenuItem("Tools/Paw Order/Investigations/Generate Evidence Preview (CSV)")]
        public static void GeneratePreviewOnly()
        {
            Process(applyToAssets: false);
        }

        [MenuItem("Tools/Paw Order/Investigations/Generate Evidence Preview + Apply")]
        public static void GeneratePreviewAndApply()
        {
            Process(applyToAssets: true);
        }

        private static void Process(bool applyToAssets)
        {
            Dictionary<string, CharacterData> suspects = LoadSuspects();
            Dictionary<string, string> questionByQid = LoadQuestionLookup();
            string[] outcomeGuids = AssetDatabase.FindAssets("t:InteractionOutcomeData", new[] { OutcomesRoot });
            List<string> csvLines = new() { "outcomeId,question,targetCharacter,suspect,motivationScore,meansScore,opportunityScore,score,rationale" };
            int updated = 0;

            foreach (string guid in outcomeGuids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                InteractionOutcomeData outcome = AssetDatabase.LoadAssetAtPath<InteractionOutcomeData>(path);
                if (outcome == null || string.IsNullOrWhiteSpace(outcome.OutcomeId))
                {
                    continue;
                }

                ParseOutcomeId(outcome.OutcomeId, out string qid, out string target);
                string question = questionByQid.TryGetValue(qid, out string qText) ? qText : qid;
                string response = outcome.ResponseText ?? string.Empty;
                string responseLower = response.ToLowerInvariant();

                List<ScoreRow> rows = new();
                foreach (string suspect in Suspects)
                {
                    ScoreRow row = BuildRow(outcome.OutcomeId, question, target, suspect, responseLower);
                    rows.Add(row);
                    csvLines.Add(ToCsv(row));
                }

                if (!applyToAssets)
                {
                    continue;
                }

                SerializedObject so = new(outcome);
                SerializedProperty values = so.FindProperty("suspectEvidenceValues");
                values.arraySize = 0;
                for (int i = 0; i < Suspects.Length; i++)
                {
                    values.InsertArrayElementAtIndex(i);
                    SerializedProperty entry = values.GetArrayElementAtIndex(i);
                    entry.FindPropertyRelative("suspect").objectReferenceValue = suspects[Suspects[i]];
                    entry.FindPropertyRelative("score").intValue = rows[i].Score;
                    entry.FindPropertyRelative("motivationScore").intValue = rows[i].MotivationScore;
                    entry.FindPropertyRelative("meansScore").intValue = rows[i].MeansScore;
                    entry.FindPropertyRelative("opportunityScore").intValue = rows[i].OpportunityScore;
                }

                so.ApplyModifiedPropertiesWithoutUndo();
                EditorUtility.SetDirty(outcome);
                updated++;
            }

            string csvPath = Path.Combine(OutcomesRoot, "PawOrder_OutcomeEvidencePreview.csv").Replace("\\", "/");
            File.WriteAllLines(csvPath, csvLines, new UTF8Encoding(false));
            AssetDatabase.Refresh();

            if (applyToAssets)
            {
                AssetDatabase.SaveAssets();
            }

            Debug.Log($"[PawOrderOutcomeEvidenceTool] Outcomes={outcomeGuids.Length} Updated={updated} CSV={csvPath}");
        }

        private static ScoreRow BuildRow(string outcomeId, string question, string target, string suspect, string responseLower)
        {
            int motivation = 0;
            int means = 0;
            int opportunity = 0;
            bool mentioned = responseLower.Contains(suspect.ToLowerInvariant());

            if (mentioned) { motivation += 20; means += 20; opportunity += 20; }
            if (string.Equals(suspect, target, StringComparison.OrdinalIgnoreCase)) { opportunity += 10; }

            if (HasAny(responseLower, "motivo", "perder", "conflito", "segredo", "encobrir", "rival")) motivation += 10;
            if (HasAny(responseLower, "matar", "assassinato", "silenciar", "chantagem")) motivation += 20;
            if (HasAny(responseLower, "acesso", "entrar", "camarim", "rotina", "procedimento", "batom", "lenço", "ajuste")) means += 10;
            if (HasAny(responseLower, "veneno", "manipular", "sabotar", "raspada")) means += 20;
            if (HasAny(responseLower, "hora", "antes", "depois", "sozinho", "circulou", "frequentou", "visível")) opportunity += 10;
            if (HasAny(responseLower, "hora crítica", "segunda entrada", "duas vezes", "acesso limpo")) opportunity += 20;

            string q = question.ToLowerInvariant();
            if (HasAny(q, "motivo", "perder")) motivation += 10;
            if (HasAny(q, "acesso", "entrar", "procedimento")) { means += 10; opportunity += 10; }
            if (HasAny(q, "hora", "sozinho", "circulou")) opportunity += 10;

            if (!mentioned)
            {
                motivation = Math.Min(motivation, 30);
                means = Math.Min(means, 30);
                opportunity = Math.Min(opportunity, 30);
            }

            motivation = SnapScore(motivation);
            means = SnapScore(means);
            opportunity = SnapScore(opportunity);
            int score = Mathf.RoundToInt((motivation + means + opportunity) / 3f);
            string rationale = mentioned
                ? "citado diretamente na resposta; indício moderado conservador"
                : "sem citação direta; apenas indício contextual baixo";

            return new ScoreRow(outcomeId, question, target, suspect, motivation, means, opportunity, score, rationale);
        }

        private static Dictionary<string, CharacterData> LoadSuspects()
        {
            Dictionary<string, CharacterData> map = new(StringComparer.OrdinalIgnoreCase);
            string[] guids = AssetDatabase.FindAssets("t:CharacterData", new[] { "Assets/Project/Scriptables/Investigations/PawOrder/Characters" });
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                CharacterData character = AssetDatabase.LoadAssetAtPath<CharacterData>(path);
                if (character != null)
                {
                    map[character.name] = character;
                }
            }

            foreach (string suspect in Suspects)
            {
                if (!map.ContainsKey(suspect))
                {
                    throw new InvalidOperationException($"CharacterData não encontrado para suspeito: {suspect}");
                }
            }

            return map;
        }

        private static Dictionary<string, string> LoadQuestionLookup()
        {
            Dictionary<string, string> map = new(StringComparer.OrdinalIgnoreCase);
            string[] guids = AssetDatabase.FindAssets("t:InvestigationPromptData", new[] { "Assets/Project/Scriptables/Investigations/PawOrder/Questions" });
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                string fileName = Path.GetFileNameWithoutExtension(path);
                int idx = fileName.IndexOf('_');
                if (idx <= 0) continue;
                string qid = fileName.Substring(0, idx);
                string question = fileName.Substring(idx + 1).Replace('_', ' ');
                map[qid] = question;
            }

            return map;
        }

        private static void ParseOutcomeId(string outcomeId, out string qid, out string target)
        {
            qid = "Q00";
            target = "Unknown";
            string[] parts = outcomeId.Split('_');
            if (parts.Length >= 3)
            {
                qid = parts[1];
                target = parts[2];
            }
        }

        private static int SnapScore(int value)
        {
            int[] allowed = { 0, 10, 20, 25, 30, 40, 50, 60, 75, 80, 90, 100 };
            return allowed.OrderBy(v => Math.Abs(v - Mathf.Clamp(value, 0, 100))).First();
        }

        private static bool HasAny(string text, params string[] terms)
        {
            return terms.Any(text.Contains);
        }

        private static string ToCsv(ScoreRow row)
        {
            static string Esc(string s) => "\"" + (s ?? string.Empty).Replace("\"", "\"\"") + "\"";
            return string.Join(",",
                Esc(row.OutcomeId),
                Esc(row.Question),
                Esc(row.TargetCharacter),
                Esc(row.Suspect),
                row.MotivationScore,
                row.MeansScore,
                row.OpportunityScore,
                row.Score,
                Esc(row.Rationale));
        }

        private readonly struct ScoreRow
        {
            public ScoreRow(string outcomeId, string question, string targetCharacter, string suspect, int motivationScore, int meansScore, int opportunityScore, int score, string rationale)
            {
                OutcomeId = outcomeId;
                Question = question;
                TargetCharacter = targetCharacter;
                Suspect = suspect;
                MotivationScore = motivationScore;
                MeansScore = meansScore;
                OpportunityScore = opportunityScore;
                Score = score;
                Rationale = rationale;
            }

            public string OutcomeId { get; }
            public string Question { get; }
            public string TargetCharacter { get; }
            public string Suspect { get; }
            public int MotivationScore { get; }
            public int MeansScore { get; }
            public int OpportunityScore { get; }
            public int Score { get; }
            public string Rationale { get; }
        }
    }
}
